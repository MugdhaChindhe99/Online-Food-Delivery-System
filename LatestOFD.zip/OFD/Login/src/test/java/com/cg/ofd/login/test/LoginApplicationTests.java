package com.cg.ofd.login.test;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class LoginApplicationTests {
	
	@Test
	void contextLoads() throws Exception {
		
	}
	
}
