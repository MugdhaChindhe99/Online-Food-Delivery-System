package com.cg.ofd.login.test;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginServiceApplicationTests {
	@Test
	void contextLoads() throws Exception {
		
	}
}
